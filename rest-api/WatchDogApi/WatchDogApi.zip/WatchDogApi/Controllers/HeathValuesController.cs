﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WatchDogApi.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class HealthValuesController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IDictionary<long, string>> Get()
        {
            return HeartRateStorage.GetHeartRateValues();
        }

        [HttpPost]
        public void Post([FromBody] string value)
        {
            HeartRateStorage.AddNewValue(value);
        }

        [HttpDelete]
        public void Delete()
        {
            HeartRateStorage.ClearStorage();
        }
    }
}