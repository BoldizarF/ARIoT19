﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WatchDogApi.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IDictionary<long, string>> Get()
        {
            return ImageStorage.GetImages();
        }

        [HttpPost]
        public void Post([FromBody] string encodedImage)
        {
            ImageStorage.AddImage(encodedImage);
        }

        [HttpDelete]
        public void Delete()
        {
            ImageStorage.ClearStorage();
        }
    }
}